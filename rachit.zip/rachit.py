import streamlit as st
from langchain_huggingface import ChatHuggingFace,HuggingFaceEndpoint,HuggingFacePipeline
from langchain_groq import ChatGroq
from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder,PromptTemplate
from langchain_core.messages import SystemMessage,AIMessage,HumanMessage
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

st.title("🧠 LangChain Q&A Assistant")

# if chat history is empty, then start a new list of chat history

if "chat_history" not in st.session_state:
    st.session_state.chat_history = [
        SystemMessage(content="You are an expert question-answering chatbot.")
    ]


# Model type selection
model_type = st.selectbox("Choose Model Type:", ["Open-Source", "Closed-Source (Groq)"])

# Model name selection
if model_type == "Open-Source":
    model_name = st.selectbox("Choose Open-Source Model:", ["HuggingFace - API", "HuggingFace - Local"])
else:
    model_name = st.selectbox("Choose Groq Model:", ["Groq-LLaMA2", "Groq-Mistral"])

# User input
user_input = st.text_input("Ask a question:")

if user_input:
    # === BACKEND LOGIC STARTS HERE ===
    st.session_state.chat_history.append(AIMessage("Hey, How can I help you?"))
    st.write("Hey, How can I help you?")
    st.session_state.chat_history.append(HumanMessage(content=user_input))

    # 1. Load selected model
    # TODO: Write logic to load the selected model dynamically based on dropdown

    if(model_type=="Open-Source" and model_name=="HuggingFace - API"):
        llm= HuggingFaceEndpoint(
                repo_id="TinyLlama/TinyLlama-1.1B-Chat-v1.0",
                task="text-generation"
                )
        model=ChatHuggingFace(
            llm=llm
        )

    elif(model_type=="Open-Source" and model_name=="HuggingFace - Local"):
        llm=HuggingFacePipeline.from_model_id(
            model_id='TinyLlama/TinyLlama-1.1B-Chat-v1.0',
            task="text-generation",
        )
        model=ChatHuggingFace(
            llm=llm
        )
    
    elif(model_type=="Closed-Source (Groq)" and model_name=="Groq-LLaMA2"):
        model=ChatGroq(
            model="Llama-3.3-70b-Versatile",
        )

    elif(model_type=="Closed-Source (Groq)" and model_name=="Groq-Mistral"):
        model=ChatGroq(
            model="Mistral-Saba-24b",
        )     

    # 2. Create prompt using PromptTemplate or ChatPromptTemplate
    # TODO: Write logic to construct the appropriate prompt
# created a template that contains chat history using chat prompt template #

    
    chat_template=ChatPromptTemplate.from_messages([
        MessagesPlaceholder(variable_name='chat_history'),
        ('human','{query}')
    ])
    prompt=chat_template.invoke({'chat_history':st.session_state.chat_history,'query':user_input})

    # 3. Maintain previous chat history (optional: use MessagesPlaceholder equivalent)
    # TODO: Implement chat memory logic

    # st.session_state.chat_history is a list which stores our chat history #


    # 4. Parse the output
    # TODO: Use output parser to clean and display 
    


    # 5. Display the response
    # TODO: Show the final answer to the user
    response=model.invoke(prompt)
    st.session_state.chat_history.append(AIMessage(content=response.content))
    st.write(response.content)
